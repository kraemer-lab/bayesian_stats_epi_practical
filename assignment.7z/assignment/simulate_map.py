import geopandas as gpd
from shapely.geometry import Polygon, Point
import numpy as np
from scipy.spatial import Voronoi
import matplotlib.pyplot as plt

#####plotting parameters
plt.rcParams.update({'font.size': 12})
plt.rcParams.update({'figure.titlesize': 12})
plt.rcParams['font.family'] = "DeJavu Serif"
plt.rcParams['font.serif'] = "Cambria Math"


np.random.seed(27)

def lloyds_relaxation(vor):
    # Calculate centroids of Voronoi polygons
    centroids = []
    for region in vor.regions:
        if len(region) > 0 and -1 not in region:
            polygon = [vor.vertices[i] for i in region if i != -1]
            if len(polygon) > 2:  # Ensure polygon has at least 3 vertices
                vor_polygon = Polygon(polygon)
                centroids.append(vor_polygon.centroid)

    return np.array([centroid.coords[0] for centroid in centroids])

# Define the boundary polygon resembling the outline of a country
boundary_points = [
    (-120, -80),
    (-120, 80),
    (0, 90),
    (120, 80),
    (120, 60),
    (90, 40),
    (70, 20),
    (50, 10),
    (20, -20),
    (-20, -40),
    (-50, -60),
    (-80, -70),
    (-120, -80)
]

# Construct a boundary polygon from the points and apply buffer to soften edges
boundary_polygon = Polygon(boundary_points).buffer(2)

# Generate random points within the irregular boundary polygon
num_points = 450
points = []
while len(points) < num_points:
    point = Point(np.random.uniform(boundary_polygon.bounds[0], boundary_polygon.bounds[2]),
                  np.random.uniform(boundary_polygon.bounds[1], boundary_polygon.bounds[3]))
    if boundary_polygon.contains(point):
        points.append((point.x, point.y))

# Check if the number of points is sufficient to construct an initial simplex for Voronoi diagram
if len(points) < 4:
    raise ValueError("Not enough points to construct an initial simplex for Voronoi diagram.")

# Apply Lloyd's relaxation
num_iterations = 10
for _ in range(num_iterations):
    points = lloyds_relaxation(Voronoi(points))

# Compute Voronoi diagram from the relaxed points
vor = Voronoi(points)

# Filter out Voronoi polygons outside the boundary
voronoi_polygons = []
for region in vor.regions:
    if len(region) > 0 and -1 not in region:
        polygon = [vor.vertices[i] for i in region if i != -1]
        if len(polygon) > 2:  # Ensure polygon has at least 3 vertices
            vor_polygon = Polygon(polygon)
            clipped_polygon = vor_polygon.intersection(boundary_polygon)
            if clipped_polygon.is_empty:
                continue
            voronoi_polygons.append(clipped_polygon)

# Convert Voronoi polygons to GeoDataFrame
gdf = gpd.GeoDataFrame(geometry=voronoi_polygons, crs="EPSG:4326")

# Plot the map
fig, ax = plt.subplots(figsize=(10, 8))
gdf.plot(ax=ax, color='lightblue', edgecolor='black')

# Plot boundary
gpd.GeoSeries(boundary_polygon).plot(ax=ax, color='none', edgecolor='red')

ax.set_aspect('equal')
plt.xlabel('Longitude')
plt.ylabel('Latitude')
plt.title('Krameria')
plt.show()


rho = 0.8         # correlation
covs = [[5**2, 5*5*rho], [5*5*rho,  5**2]] 
xz = np.random.multivariate_normal([10,0], covs, len(gdf)).T

x = np.sort(xz[0])
z = np.sort(xz[1])
y = np.sort(np.random.poisson(z**2, len(gdf))*52  ) 



coords = gdf['geometry'].apply(lambda x: x.representative_point().coords[:])
coords = np.array([c[0] for c in coords])
gdf['lon'] = [c[0] for c in coords]
gdf['lat'] = [c[1] for c in coords]
gdf['coords'] = gpd.points_from_xy(coords[:,0], coords[:,1])

gdf = gdf.iloc[gdf.coords.y.argsort().values]

gdf['cases'] = y #number of people infected with probabilis fever per region
gdf['temperature'] = x #average annual temperature per region

fig, ax = plt.subplots(figsize=(10, 8))
gdf.plot(ax=ax, column="temperature", edgecolor='black', cmap="coolwarm", 
         legend=True, norm=plt.Normalize(vmin=-5, vmax=25), 
         legend_kwds={"shrink":.5, 'label':"Celcius"})
ax.axis("off")
ax.set_title("Krammeria's average annual temperature")

fig, ax = plt.subplots(figsize=(10, 8))
gdf.plot(ax=ax, column="cases", edgecolor='black', cmap="viridis", 
         legend=True, norm=plt.Normalize(vmin=0, vmax=y.max()), 
         legend_kwds={"shrink":.5, 'label':"Cases"})
ax.axis("off")
ax.set_title("Krammeria's probabilis fever cases")


vowels = ['a','e','i','o','u']
consonants = ['k', 'l', 'r', 't', 's', 'v', 't', 'd', 'y']

names = []
for i in range(len(gdf)):
    v1 = vowels[np.random.randint(5)]
    c1 = consonants[np.random.randint(9)]
    l1 = [v1, c1]
    np.random.shuffle(l1)
    v2 = vowels[np.random.randint(5)]
    c2 = consonants[np.random.randint(9)]
    l2 = [v2, c2]
    np.random.shuffle(l2)
    v3 = vowels[np.random.randint(5)]
    c3 = consonants[np.random.randint(9)]
    l3 = [v3, c3]
    np.random.shuffle(l2)
    names.append(l1[0].upper() + l1[1] + l2[0] + l2[1] + l3[0] + l3[1])
        
        
gdf['region'] = names
gdf['region_code'] = ["R"+str(i+1) for i in range(len(gdf))]

gdf = gdf.drop("coords", axis=1)
gdf.to_file("./shapefiles/sim_country.shp")

data = gdf.drop("geometry", axis=1)
data.to_csv("sim_data.csv", index=False)
